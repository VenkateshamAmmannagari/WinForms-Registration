﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;

namespace HelpText
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void BtnLogin_Click(object sender, EventArgs e)
        {
             //String connString = ConfigurationManager.ConnectionStrings["dbConnection"].ToString();

            string connectionString = "Server=vishu;Database=LearningDB;Trusted_Connection=Yes";
            using (SqlConnection sqlConnection = new SqlConnection(connectionString))
            {
                string userName = txtUserName.Text;
                string password = txtPassword.Text;

                string query = "SELECT count(*) FROM UserLogin where UserName = '" + userName + "'  and UserPassword = '" + password + "'";
                SqlCommand sqlCommand = new SqlCommand(query, sqlConnection);
               
                sqlConnection.Open();
                int result = Convert.ToInt32(sqlCommand.ExecuteScalar());
                sqlConnection.Close();

                if (result >=1)
                {
                    this.Hide();
                    EmployeeDetails employeeDetails = new EmployeeDetails();
                    employeeDetails.ShowDialog();
                }
                else
                {
                    MessageBox.Show("Loging Failed. If user is not registered please click on Register button");
                }

            }
        }

        private void BtnRegister_Click(object sender, EventArgs e)
        {

            string connectionString = "Server=vishu;Database=LearningDB;Trusted_Connection=Yes";
            using (SqlConnection sqlConnection = new SqlConnection(connectionString))
            {
                sqlConnection.Open();
                string query = "insert into UserLogin values(@p1,@p2,@p3,@p4)";
                SqlCommand cmd = new SqlCommand(query, sqlConnection);
                cmd.Parameters.AddWithValue("@p1", txtUserName.Text);
                cmd.Parameters.AddWithValue("@p2", txtPassword.Text);
                cmd.Parameters.AddWithValue("@p3", DateTime.Now);
                cmd.Parameters.AddWithValue("@p4", DateTime.Now);
                cmd.CommandType = CommandType.Text;
                int result = cmd.ExecuteNonQuery();
                sqlConnection.Close();
                if (result != 0)
                {
                    MessageBox.Show("Registered successfully");
                }
                else
                {
                    MessageBox.Show("Registration Failed");
                }
            }
        }

        private void BtnRegister_Click_1(object sender, EventArgs e)
        {
            string connectionString = "Server=vishu;Database=LearningDB;Trusted_Connection=Yes";
            using (SqlConnection sqlConnection = new SqlConnection(connectionString))
            {
                sqlConnection.Open();
                string query = "insert into UserLogin values(@p1,@p2,@p3,@p4)";
                SqlCommand cmd = new SqlCommand(query, sqlConnection);
                cmd.Parameters.AddWithValue("@p1", txtUserName.Text);
                cmd.Parameters.AddWithValue("@p2", txtPassword.Text);
                cmd.Parameters.AddWithValue("@p3", DateTime.Now);
                cmd.Parameters.AddWithValue("@p4", DateTime.Now);
                cmd.CommandType = CommandType.Text;
                int result = cmd.ExecuteNonQuery();
                sqlConnection.Close();
                if (result != 0)
                {
                    MessageBox.Show("Registered successfully");
                }
                else
                {
                    MessageBox.Show("Registration Failed");
                }
            }
        }
    }
}
