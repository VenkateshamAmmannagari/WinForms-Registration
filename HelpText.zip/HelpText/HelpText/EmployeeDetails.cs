﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HelpText
{
    public partial class EmployeeDetails : Form
    {
        public EmployeeDetails()
        {
            InitializeComponent();
        }

        private void BtnShowDetails_Click(object sender, EventArgs e)
        {
            string connectionString = "Server=vishu;Database=LearningDB;Trusted_Connection=Yes";
            using (SqlConnection sqlConnection = new SqlConnection(connectionString))
            {
                sqlConnection.Open();
                string query = "select * from UserLogin";
                SqlCommand cmd = new SqlCommand(query, sqlConnection);

                cmd.CommandType = CommandType.Text;
                using (SqlDataAdapter sda = new SqlDataAdapter(cmd))
                {
                    using (DataSet ds = new DataSet())
                    {
                        sda.Fill(ds);
                        grdEmployeeDetails.DataSource = ds.Tables[0];
                    }
                }
                sqlConnection.Close();
            }
        }

        private void EmployeeDetails_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'learningDBDataSet.UserLogin' table. You can move, or remove it, as needed.
            this.userLoginTableAdapter.Fill(this.learningDBDataSet.UserLogin);

        }
    }
}
